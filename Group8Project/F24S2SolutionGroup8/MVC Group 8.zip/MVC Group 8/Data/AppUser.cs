﻿namespace MvcGroup8.Data
{
    internal class AppUser
    {
        public object UserName { get; internal set; }

        internal class AppUser : Data.AppUser
        {
            private string v1;
            private string v2;
            private string v3;
            private string v4;

            public AppUser(string v1, string v2, string v3, string v4)
            {
                this.v1 = v1;
                this.v2 = v2;
                this.v3 = v3;
                this.v4 = v4;
            }
        }
    }
}